Manual

1. set configuration variables for monte carlo simulation.
 - open inputdat.m file. You can see global many variables.
 - Among them configuration variables for monte carlo simulation are
	global xdim
	global ydim
	global zdim

	global areafrac % controlling parameters which specify area fraction of -1 spin
	global resume % the function to select one of the options or initial configuration
	global infname % stores the name of input microstructure file name

	global maxMCS
	global curMCS
	global photoMCSInterval

	global kT
	global J


 A. You can select monte carlo simulation mode
    if 'resume = 0', it opens input file with name infname,
    read contents inside the file, then change the data value such that new data = data read + 1000,
    it doesn't execute monte carlo simulation
    and writes output file named ��test_micro_1000.vtk��.

    if 'resume = 1', it opens input file with name infname, 
    read contents inside the file to prepare executing monte carlo simulation. 
    And does monte carlo simulation.
    and writes output file named ��test_resume1_...MCS.vtk��.

    if 'resume = 2', it prepares a random initial configuration
    with prescribed area fraction between 2 possible spin states, 1 or -1.
    and writes output file named ��test_resume2_...MCS.vtk��.

    if 'resume = 3', it draws a circle with a prescribed radius inside the simulation domain.
    the circle has spin value of -1, and the matrix has 1 as its spin.
    and writes output file named ��test_resume3_...MCS.vtk��.

 B. you can change 'xdim', 'ydim', 'zdim'
    number of pixels in x, y and z directions. They must be the same in an input microstructure, 
    if any. For 2d simulation, zdim = 1 but this is only for outputting vtk images

 C. 'areafrac' is controlling parameters which specify area fraction of -1 spin.

 D. you can set 'maxMCS', 'photoMCSInterval'
    maxMCS determines how much MCS executed during main funciton.
    photoMCSInterval determines interval to create output files.

 E. You can set 'kT' value and 'J' value for sweep_Ising


2. IF you finished configuration setting, open mcIsing2d.m and execute it.